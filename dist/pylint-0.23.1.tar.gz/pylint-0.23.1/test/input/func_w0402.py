"""test wildard import
"""
__revision__ = 0

from input.func_fixme import *

def abcd():
    """use imports"""
    function()
